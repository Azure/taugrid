# kueue (AKS fork)

AKS fork of the [upstream Kueue](https://github.com/kubernetes-sigs/kueue) Helm chart. The chart is vendored into this repository so AKS customizations can be layered on top of an upstream release, and it carries the **managed Kueue extension** — the controllers that derive Kueue objects from the cluster's own hardware.

| | |
|---|---|
| **Upstream chart** | [kubernetes-sigs/kueue](https://github.com/kubernetes-sigs/kueue) |
| **Upstream version** | [`UPSTREAM_VERSION`](UPSTREAM_VERSION) |
| **Extension release version** | [`AKS_VERSION`](AKS_VERSION) |
| **Published chart version** | composed at publish time — see [Versioning](#versioning) |
| **ACR location** | `oci://aksmcrimagescommon.azurecr.io/public/aks/ai-runtime/helm/kueue` |
| **Extension controller** | [`controllers/kueue-extension/README.md`](../../controllers/kueue-extension/README.md) |

## Fork strategy

Files under `charts/kueue/` are **raw upstream**. Every AKS change lives in a sibling file that upstream does not know about, so a sync can overwrite the upstream files without touching ours:

| AKS-owned | Merged into | At |
|---|---|---|
| `chart-aks-overrides.yaml` | `Chart.yaml` | publish time |
| `values-aks-overrides.yaml` | `values.yaml` | publish time |
| `templates-aks/*.yaml` | `templates/` | publish time |
| `tests-aks/*.yaml` | `tests/` | publish time |
| `patches/*.patch` | individual upstream files | publish time |
| `AKS_VERSION` | the composed chart version | publish time |

All of it is applied by the shared
[`scripts/ci/apply-chart-aks-overrides.sh`](../../scripts/ci/apply-chart-aks-overrides.sh)
helper, which is the single entry point every consumer calls.

`UPSTREAM_VERSION` records which upstream release the fork is based on. The sync pipeline writes it **last**, so it doubles as a completion marker: if it is current, every earlier step of that sync ran.

⚠️ **Never put an AKS template directly in `templates/`.** The sync pipeline wipes that directory with `rm -rf`, recopies from upstream, and commits with `git add -A` — an AKS file placed there is deleted by the next sync with nothing failing. Only `templates-aks/` survives. The script treats a missing or empty `templates-aks/` as a hard error rather than a skip, because the failure it guards against is silent deletion.

### CRD uninstall behaviour (no retention annotation, with one exception)

Uninstalling Managed Kueue deletes all Kueue custom resources in the cluster, including customer-created LocalQueues, ClusterQueues, Workloads, Cohorts, AdmissionChecks, ResourceFlavors, and other Kueue configuration. It also clears finalizers that would block deletion.

Keep customer-owned configuration, such as LocalQueues, ClusterQueues, AdmissionChecks, and ResourceFlavors, in Git or export it before uninstalling. Reapply it after reinstalling Kueue and before admitting queued Jobs. If you use GitOps, pause reconciliation before uninstalling and resume it after Kueue is reinstalled.

Kueue-managed Kubernetes Jobs and their Pods are not deleted:

- Running Jobs and Pods continue without Kueue management.
- Queued Jobs remain suspended and do not create Pods.
- After Kueue is reinstalled, it creates new Workloads for surviving Jobs that still have a queue label.

The CRDs under `templates/crd/` are ordinary release resources, so `helm uninstall` deletes them. This is deliberate. The chart does **not** carry `"helm.sh/resource-policy": keep`, and the sync pipeline asserts it stays absent.

Retaining the CRDs would make a reinstall fail on resources that already exist, which forces the extension registration to adopt whatever it finds instead. That adoption cannot be conditioned on where the resources came from, so it applies equally to a Kueue the customer installed themselves — and **we then have to support whatever configuration they were running**, sight unseen. Failing the install is the outcome we want: we do not know their configuration, so we should not silently take responsibility for it.

The `ProvisioningRequest` CRD under `templates-aks/` is the one exception, and it is one because the argument above does not apply to it: its content is not the customer's, it is an upstream-defined schema, and it is byte-identical whoever installed it. It carries `helm.sh/resource-policy: keep` and uses a cluster lookup to render only when the CRD is absent — see [the provisioning section](#custom-provisioningrequest-provider-controllerenableprovisioningreq) below. The sync pipeline's no-retention assertion globs `templates/crd/*.yaml` only, so it does not cover that file.

## Managed extension identity

The Public Preview extension instance name is `aks-kueue`. Extension Manager
uses the instance name as the Helm release name, which keeps failed-extension
cleanup from targeting the upstream installation default `kueue`.

The AKS values pin `fullnameOverride: kueue`, so this Helm identity change does
not rename the Kubernetes resources. The manager, extension controller,
Services, webhooks, and hook Jobs retain their `kueue-*` names. Their
`app.kubernetes.io/instance` label and Helm annotations still identify the real
`aks-kueue` release.

This split preserves control-plane allowlists and the existing vmagent, alert,
and TSG contracts. It is defense in depth for Preview; Extension Manager still
needs a platform-owned release check before uninstall.

## Versioning

Three version numbers are in play, and they move independently. Conflating them is the most common mistake when working on this chart.

| Number | Lives in | Bumps when | Appears as |
|---|---|---|---|
| Upstream Kueue | `UPSTREAM_VERSION` | a sync pulls a new upstream release | left half of the chart version |
| **Extension release** | `AKS_VERSION` | **any** published chart change | right half of the chart version |
| Controller build | *nothing in the repo* | every controller commit | the image **digest** pinned in `values-aks-overrides.yaml` |

### The published chart version

```
<upstream>-aks.<AKS_VERSION>          e.g.  0.19.2-aks.0.3.0
```

Composed by `scripts/ci/apply-chart-aks-overrides.sh`, not committed to
`Chart.yaml` — whose `version` tracks upstream and is overwritten by every
sync, and which says "do not modify manually" for that reason. Composing in
the shared helper rather than in the publish pipeline means all consumers —
publish, chart integration test, helm CI — see the same version, instead of
only the publish path.

**Neither half resets.** A new upstream release does not reset `AKS_VERSION`, and an extension release does not touch the upstream half.

⚠️ **`aks.` is a separate dot-separated identifier and must never be glued to the number.** SemVer §11.4 compares alphanumeric identifiers lexically, so a glued `aks10` sorts *below* `aks8` — the ordering inverts silently once the major reaches double digits. `helm lint` accepts the glued form without complaint, which is why the format is pinned by a test rather than by a comment.

`AKS_VERSION` starts at **0.1.0**. The `0.x` is deliberate while the managed-extension surface is still evolving. The maturity belongs in the version rather than in an `alpha` identifier, which would sort *above* every numbered release.

### The controller image is versioned by git SHA, not by `AKS_VERSION`

They answer different questions. `AKS_VERSION` is *which extension release* a customer has; the image identifies *which build of the controller* is running. Tying the image to `AKS_VERSION` would force a chart release for every controller commit and make the two impossible to reason about separately.

The image is built and pushed by [`.pipelines/publish-kueue-extension-controller.yml`](../../.pipelines/publish-kueue-extension-controller.yml), tagged from the commit SHA, and pinned here **by digest**:

```yaml
aksExtension:
  controller:
    image:
      repository: mcr.microsoft.com/aks/ai-runtime/kueue-extension-controller
      tag: ""       # must stay empty in the shipped values
      digest: ""    # required
```

**The digest is required and the render fails without it.** A tag on an MCR-syncing registry is mutable — this chart has already published one version twice under different digests, both runs green, with the later silently served.

**The shipped values must leave `tag` empty**, and `tests-aks/aks_shipped_image_test.yaml` enforces it. The template still emits `repository:tag@digest` when a tag is set, which is useful for a local build, but a tag beside a digest is never verified against it: the runtime resolves the digest and ignores the tag, so `repository:doesnotexist@<digest>` pulls successfully. A stale tag in a release would name a build that is not running while looking exact.

### Releasing a chart change

1. Land the controller change and let its publish pipeline push the image.
2. Copy the digest it prints into `values-aks-overrides.yaml`.
3. Bump `AKS_VERSION` — patch for a fix, minor for new surface.
4. Merge to `main`. The publish pipeline does the rest.
5. Continue with the [managed extension release runbook](../../docs/kueue/managed-extension-release.md) to register the published version, validate canary, and run final CRUD acceptance.

## Managed HTTP metrics sidecar

`aksExtension.metricsProxy.enabled` adds a pass-through HTTP exporter to **each
upstream controller-manager pod**. Managed releases enable it by default; an
explicit `false` remains available for coordinated rollback. This does not change
or fork the upstream Kueue image, and does not depend on the unreleased loopback
access-control opt-out in KEP-16029.

```text
vmagent -> HTTP podIP:8080/metrics (no target credential)
        -> metrics-proxy sidecar
        -> HTTPS 127.0.0.1:8443/metrics + rotating pod-local ServiceAccount token
        -> upstream Kueue manager
```

**Security / activation gate:** the HTTP endpoint has no authentication,
encryption, or caller isolation. Anyone able to reach it can read queue,
workload and capacity metrics, and HTTP does not protect metrics integrity.
Owner/security approval of that exposure and suitable network restrictions are
required before publishing and rolling out this default-on release. The chart
does not install a generic NetworkPolicy: Konnectivity ingress sources depend on
the cluster topology, and a blanket policy could block the admission webhook or
existing visibility traffic. `hostNetwork` and non-ClusterIP metrics Services are
rejected while the proxy is enabled.

The backend remains authenticated HTTPS on a literal loopback address. The proxy
accepts Kueue's self-signed serving certificate **only on that fixed local hop**;
it never uses environment proxies, follows redirects, forwards caller tokens or
cookies, or accepts another upstream URL. All containers in this pod must be
trusted with its ServiceAccount. This is not a general TLS-verification opt-out.
No HCP token, client certificate, CA signing key, certificate-issuing controller,
or cert-manager installation is needed for the exporter.

The chart projects a kubelet-rotated token for the manager's ServiceAccount and
binds it to the existing `kueue-metrics-reader` ClusterRole (`GET /metrics`). Its
existing TokenReview/SAR permissions are not sufficient on their own. Kueue
still performs both checks for each uncached credential/authorization decision.
The proxy reads the token file on every scrape; it never embeds a static token
in a ConfigMap or argument.

The `/kueue-metrics-proxy` binary ships in the **existing extension-controller
image**, built by its existing CI/publish pipeline. The controller, cleanup
entrypoint and proxy use **one shared `aksExtension.controller.image` pin**;
there is no second proxy repository/digest/pullPolicy to drift. The shipped pin
identifies a published multi-platform build containing all three binaries.
Validate its public digest, binaries, and required security properties before
changing the pin. The shared pin applies even when
`enableKueueObjectsAutomation=false` (for example on MultiKueue managers).

**Managed-release activation:** `az k8s-extension` does not expose arbitrary
chart parameters, so the managed default must not depend on customers enabling
`metricsProxy.enabled`. No extra customer chart settings are required for this
release. Before publishing and rolling it out, obtain the required owner/security
approval and validate the actual aks-operator underlay/overlay/Konnectivity path.
A Kind or direct HTTP test is not sufficient to establish release acceptance.

When enabled, the chart owns the manager metrics bind address
`127.0.0.1:8443`. The manager port becomes `metrics-local`; the sidecar alone
owns named port `metrics` on 8080. The existing metrics Service and both optional
ServiceMonitors use HTTP/8080 without target tokens or TLS configuration. The
webhook, health and visibility listeners, leader election, and metric collection
settings are unchanged. Disabling the feature restores the original chart path.
The generated scrape `up` series identifies the sidecar image; use
`kueue_build_info` for the actual upstream Kueue version.

Each request fetches fresh upstream bytes (including metric names, labels,
Content-Type and OpenMetrics negotiation); there is no metric cache or second
metrics registry. Token errors, backend 401/403, redirects, timeouts and
incomplete/oversized bodies fail the scrape rather than returning stale metrics.
Three concurrent scrapes support managed vmagent plus the OSS and Azure
ServiceMonitors together. A fourth waits up to 250 ms for a slot before receiving
503; cancellation ends the wait early. The 32 MiB per-response limit and a
10-second backend timeout bound active work; the default 384 MiB memory limit
allows response-buffer growth/GC/TLS headroom for all three collectors. `/healthz` checks process health only so an API auth outage does
not cause probe-driven restarts of the scheduler/webhook pod.

### Coordinated rollout and rollback

1. Verify the published shared image and obtain approval for the anonymous metrics surface.
2. Install or upgrade a canary through the supported managed-extension lifecycle
   using the exact default-on chart version. This rolls the manager pods because
   their config checksum and container list change. Validate HTTP `/metrics`,
   local-token authorization/rotation, the required AKS Pod ownership labels,
   and that podIP:8443 is no longer exposed.
3. Deploy the companion `aks-operator` AI Runtime scrape change: select container
   `metrics-proxy`, port `metrics`/8080, scheme `http`, and **no target**
   `bearer_token_file` or `tls_config`. Keep job `kueue_controller_manager`,
   metric allowlists, aggregations and discovery authentication unchanged. The
   shared HTTP overlay proxy keeps its existing Konnectivity authentication.
4. Require the expected vmagent targets to be `Up=1` and verify metric receipt in
   the intended production ingestion path before fleet use. A local E2E receiver
   proves transport, not ADX ingestion.

Do not roll out the operator change alone: clusters without the sidecar have no
matching target. Do not leave old HTTPS-only consumers pointed at podIP:8443
after enabling loopback binding. Roll back the chart and scrape configuration in
a coordinated change, accepting a collection gap where necessary; do not add a
fallback that sends `hcpService` to an unverified target. No image is published,
feature enabled, or security finding waived merely by landing this code.

A repeatable CPU-only real-Kubernetes test harness is documented in
[`tests/e2e/kueue/metricsproxy`](../../tests/e2e/kueue/metricsproxy/README.md).
It exercises actual Kueue auth, vmagent discovery/remote-write, token rotation and
failure propagation on a disposable cluster. Its direct-cluster transport does
not replace the required AKS Konnectivity validation.

## Controller placement on AKS

The AKS defaults require non-virtual Linux nodes and exclude hosted system nodes.
They give `kubernetes.azure.com/mode=system` a soft scheduler preference. If no
preferred node can be used, a controller may run on any eligible node and stays
there until its Pod is replaced. Nodes without AKS-specific labels are eligible,
including non-hosted Flex-attached and non-AKS Linux nodes. This defines
scheduler eligibility, not a separate support guarantee for those environments.
The repository's AKS AI Runtime GitOps values keep their hard system-node
selector. On Automatic, NAP may provision `system-surge` capacity instead of
using existing user capacity.

The managed chart uses one manager replica so installation does not require
capacity for a warm follower on constrained system pools.

The manager, extension controller, and lifecycle hook Jobs tolerate
`CriticalAddonsOnly:NoSchedule`. They do not tolerate the protected hosted-node
taint, so this does not onboard Kueue onto AKS-managed hosted nodes.

Affinity term lists and toleration lists are replaced by Helm overrides rather
than appended. A custom required term must repeat the non-virtual, Linux, and
non-hosted constraints if those protections are still wanted. Custom
tolerations must repeat `CriticalAddonsOnly` to remain eligible for tainted
system pools. Use `affinity: null` and `tolerations: []` to remove the defaults;
an empty affinity map keeps them. Parent-chart null handling must be verified by
the parent chart.

The critical toleration is protected on Automatic by request identity. Offline
rendering does not prove Extension RP entitlement. A new immutable extension
version must pass managed-extension create and upgrade validation on Automatic
before release.

## The managed extension

The chart ships the extension controller, its RBAC, and a pre-delete hook. Everything is under the `aksExtension` key in [`values-aks-overrides.yaml`](values-aks-overrides.yaml); what the controllers actually do is documented in [`controllers/kueue-extension/README.md`](../../controllers/kueue-extension/README.md).

```yaml
aksExtension:
  enableKueueObjectsAutomation: true
```

**On by default.** The managed extension is the reason to use this chart instead of upstream Kueue. Fleet disables automation on MultiKueue manager clusters, which manage these objects themselves. It is a single switch on purpose: separate "install the controller" and "let it act" toggles would be Helm values set the same way, and *automation on, controller off* would render nothing while reporting success.

Chart integration tests still set the value explicitly and redirect classification labels to a test-only prefix. That keeps chart and controller validation independent of the regional rollout of the AKS node-label webhook allowlist.

⚠️ **The production prefix requires the AKS node-label webhook allowlist.** Without that control-plane change, the controller stays healthy but its `kubernetes.azure.com/*` writes are denied, so it cannot generate ResourceFlavors or Topology from the cluster's nodes.

⚠️ **The release namespace must be `kueue-system`** — `templates-aks/_helpers-aks.yaml` enforces this by failing the render.

### Logging contract

The chart configures its controllers independently:

| Controller | Managed verbosity | Purpose |
|---|---:|---|
| `kueue-controller-manager` | `1` | Retains lifecycle, health, Kubernetes Event, Info, and Error context without the high-volume V(2) reconcile traces. |
| `kueue-extension` | `3` | Retains node-classification and managed-object reconciliation outcomes emitted at V(3). |

These are platform-owned release defaults. The Extension RP does not expose them through its supported customer `configurationSettings` contract. A temporary-verbosity support procedure must be defined and validated before relying on higher manager verbosity during incidents.

Reassess both defaults against preview incidents, fleet-wide log volume and workload-detail exposure, and the logging layout of each Kueue version selected for release. The extension stays at `3` unless its own measured volume or log placement changes.

### Error diagnostics

The [error-message inventory](../../controllers/kueue-extension/docs/ERROR-MESSAGES.md)
identifies AKS-owned render failures, admission denials, controller logs, optional
provider conditions, and cleanup summaries. It separates customer errors from
platform-owned packaging failures and inherited Kubernetes/Helm errors. Use the
linked managed Kueue TSG for operational recovery; source wording is not proof
that a controller image, chart, or troubleshooting page has been deployed.

### Supported workload types

The managed extension enables these Kueue workload integrations:

| Workload family | Kueue framework identifiers |
|---|---|
| Kubernetes workloads | `batch/job`, `pod`, `deployment`, `statefulset` |
| JobSet | `jobset.x-k8s.io/jobset` |
| KubeRay | `ray.io/rayjob`, `ray.io/rayservice`, `ray.io/raycluster` |
| Kubeflow | `kubeflow.org/mpijob`, `trainer.kubeflow.org/trainjob` |

This fixed allowlist is the Managed Kueue product support boundary. The legacy Kubeflow Trainer v1 integrations (`paddlejob`, `pytorchjob`, `tfjob`, `xgboostjob`, and `jaxjob`) remain disabled because Kueue 0.19 deprecates them in favor of Trainer v2 `TrainJob`. `AppWrapper` and `LeaderWorkerSet` are also excluded. The AKS overlay replaces the broader upstream default so an upstream chart sync cannot silently expand the supported set. Customers who install the upstream Helm chart directly own their integration configuration and its support implications.

### Existing controller preflight

The AKS chart labels the upstream Kueue controller-manager and optional
extension-controller Deployments and their Pod templates with
`kubernetes.azure.com/managedby=aks`. The manager uses an AKS-owned publish-time
patch; the extension uses its AKS-owned template. Both stamp the literal marker
without a chart value that can remove or replace it.

The marker is not added to either Deployment's immutable selector. Existing
Pods acquire it through the normal rolling upgrade, so roll out the updated
chart before requiring the marker in pod-level metrics discovery. This label
scopes ownership; it is not an authentication or authorization boundary.

During every install, upgrade, and rollback render, Helm queries Deployments
across the cluster and fails with an actionable error if it finds a Kueue
controller that is not both marked as AKS managed and owned by the current Helm
release.

The preflight recognizes the standard `app.kubernetes.io/name=kueue` label
when paired with the controller component or with the control-plane label and
standard manager configuration. It independently recognizes a `manager`
container using the exact upstream or AKS MCR Kueue image repository (tagged or
digest-pinned). This catches both the upstream Helm chart and upstream Kustomize manifests, including installations in another
namespace. Kueue's webhooks and cluster-scoped scheduling objects make the
controller a cluster singleton; running an OSS controller beside the managed
extension is unsupported.

The check is unconditional and has no disable path. For compatibility, the
first upgrade from an older AKS chart that predates the marker is allowed only
when the existing Deployment has the exact current release identity, uses the
AKS MCR Kueue image, and carries an AKS-versioned `helm.sh/chart` label containing
`-aks.`. That upgrade adds the marker. The public MCR image alone is not treated
as managed provenance: an OSS chart is rejected even if its image, Helm
annotations, and object name imitate the managed release.

This uses Helm's `lookup` and `fail` template functions rather than a
`pre-install` hook Job. Helm validates ownership of ordinary release resources
before running that hook, so a hook cannot intercept an existing
controller-manager collision. Helm also processes the chart's `crds/` directory
before hooks.

Client-only `helm template` and `--dry-run` do not contact the Kubernetes API,
so they cannot exercise the live lookup. Use `--dry-run=server` or a real
install to validate the preflight against cluster state.

### Workload priority classes

When automation is enabled, the chart creates three cluster-scoped `WorkloadPriorityClass` objects:

| Name | Value |
|---|---:|
| `aks-high-priority` | `1000` |
| `aks-medium-priority` | `500` |
| `aks-low-priority` | `100` |

These are static objects managed by Helm release hooks, not ordinary release manifests or controller
output. A post-install/post-upgrade/post-rollback Job waits for the CRD and server-side applies them;
a pre-delete Job removes their exact names. They keep `app.kubernetes.io/managed-by: Helm` and Helm
release annotations to identify the lifecycle owner, and carry
`kueue-extension.aks.azure.com/vap-protected: "true"` for admission protection. The three names are
reserved: callers outside the common platform allowlist cannot create, edit or delete them even if
the marker is absent.

### Native ProvisioningRequest defaults

When managed-object automation is enabled, the chart installs
`aks-provisioning-config` and `aks-provisioning-check` for Kueue's built-in
ProvisioningRequest controller. The config selects
`best-effort-atomic-scale-up.autoscaling.x-k8s.io` and leaves
`managedResources` unset. ClusterQueue owners choose where the check applies
with `admissionChecksStrategy.onFlavors`.

The external `autoscaling.x-k8s.io/v1` ProvisioningRequest API is a startup
prerequisite for Kueue. Install and establish that CRD before Kueue starts. If
CAS installs the CRD later, restart the Kueue controller-manager, wait for its
rollout, and require `AdmissionCheck/aks-provisioning-check` to report
`Active=True` before referencing it from a ClusterQueue. Kueue does not register
this controller dynamically after startup.

Object presence and readiness are deliberately separate: the managed pair is
installed even when the external API is absent, while `Active=True` is the
signal that native provisioning can be used.

### Custom ProvisioningRequest provider (`controller.enableProvisioningReq`)

```yaml
aksExtension:
  controller:
    enableProvisioningReq: false
```

Turns on the `AdmissionCheck` + `ProvisioningRequest` controllers, which back Kueue admission with cluster-autoscaler capacity. It is nested under `controller.*` rather than being a top-level `aksExtension` key, so it stays out of the Fleet-only privileged set that the RP validator matches by exact string — it is ordinary chart config, settable by any caller.

One flag moves three things that have to move together:

- the `--enable-provisioning-req` argument on the controller Deployment,
- the delete grants on `provisioningrequests`, `podtemplates` and `pods` in `templates-aks/extension-controller-rbac.yaml` (the base rules carry no delete verbs at all; this is the documented exception, and it is the steady-state loop — a request that times out must release its placeholder Pods or the capacity it asked for is never returned),
- the `ProvisioningRequest` CRD in `templates-aks/provisioningrequest-crd.yaml`.

Enabling the controllers without the grants leaves every reconcile failing `Forbidden`; without the CRD the controller cannot create the request at all. The binary itself defaults to `false`, and the chart omits the flag while the feature is off so the binary default and the RBAC/CRD gates stay aligned.

Kueue's built-in ProvisioningRequest AdmissionCheck controller can produce requests for the AKS provider by using `controllerName: kueue.x-k8s.io/provisioning-request` with a `ProvisioningRequestConfig` whose class is `best-effort-scale-up.aks.azure.com`. Kueue discovers the shared ProvisioningRequest API only during process startup. The AKS manager-template patch therefore adds a pod-template marker while provisioning is enabled, forcing a Kueue rollout when an existing Helm release first enables the provider. The extension still owns fulfillment of the custom class; the rollout does not enable Cluster Autoscaler's reserved ProvisioningRequest classes.

⚠️ **The `ProvisioningRequest` CRD is not ours alone.** It is a shared, upstream-defined type in the `autoscaling.x-k8s.io` group, and any number of components may have installed it before us — we deliberately do not assume which. The chart therefore never takes over a pre-existing copy and never deletes the shared schema:

- **It is retained on uninstall.** A CRD created by this chart carries `helm.sh/resource-policy: keep`. Deleting a CRD cascade-deletes every custom resource of that kind, so an uninstall here would take out any in-flight `ProvisioningRequest`s another component owns along with ours. This is the opposite of the policy for the Kueue CRDs above, for the reason given in [that section](#crd-uninstall-behaviour-no-retention-annotation-with-one-exception).
- **A pre-existing compatible CRD is left untouched.** `templates-aks/provisioningrequest-crd.yaml` uses Helm's cluster `lookup` before emitting an ordinary release resource. If the CRD already exists and serves `v1`, the template renders nothing, so Helm has no foreign resource on which to fail its pre-hook ownership check and no metadata is rewritten. If it exists without a served `v1`, rendering fails with an explicit compatibility error. If it is absent, the chart creates the upstream definition and retains it on uninstall.

A pre-install adoption Job cannot solve this ordering: Helm checks ordinary resources for ownership conflicts before executing hooks. Conditional creation avoids submitting the conflicting resource at all.

Note that the CRD **YAML** is a copy, unlike the Go types, which are imported from `k8s.io/autoscaler`. Helm has no render-time fetch: a chart can only ship bytes. The drift surface is that one file.

It lives in `templates-aks/` rather than `crds/` because `crds/` installs unconditionally — the gate is the whole point — and a file placed in `templates/` would be deleted by the next upstream sync.

### The managed-object guard

`templates-aks/managed-object-guard-policy.yaml` ships one `ValidatingAdmissionPolicy` that protects
objects marked `kueue-extension.aks.azure.com/vap-protected: "true"`. Lifecycle ownership is
separate: controller-generated objects keep the controller's managed-by value while WPCs keep
Helm's.

Reserved names close the gap before an object exists or after a marker is stripped: every
ResourceFlavor beginning `aks-`, Topology `aks-default`, and the three WPC names are protected even
without the marker. Other names remain available to customers.

The policy prevents but does not repair. A write from an allowlisted identity is not refused, and a
controller-generated object is corrected only on the next Node event.

```mermaid
flowchart TD
    W["write to a kueue.x-k8s.io object<br/>CREATE / UPDATE / DELETE"] --> M{"vap-protected on new/old object<br/>OR reserved name for this resource?"}
    M -->|no| ALLOW1["allowed — customer namespace"]
    M -->|yes| U{"writer on the allowlist?"}
    U -->|"acsService, aksService, aks-support,<br/>clusterAdmin, our controller,<br/>kueue-controller-manager, the uninstall hook,<br/>anything under aks:trustedaccess:"| ALLOW2["allowed"]
    U -->|"anyone else, incl. masterclient"| DENY["denied"]
```

Six things about it are easy to get wrong:

- **The marker test reads both sides.** Testing only the new object lets a caller strip the marker in
  the same UPDATE and escape for good.
- **Reserved names are resource-scoped.** `aks-*` is reserved for ResourceFlavor only;
  `aks-default` is reserved for Topology only; WPCs use an exact three-name list.
- **Both null guards are required.** On a DELETE the API server sends a null object, and
  `.metadata` is a plain select that raises on null. An erroring match condition under
  `failurePolicy: Fail` is a denial, so dropping a guard denies every delete, uninstall included.
- **`username` is optional-chained for the same reason.** It is `omitempty`, so the key is absent on
  an empty value and a plain select raises. That denies every write to every managed type.
- **Hook ServiceAccounts are fixed literals**, not release-derived, because the allowlist matches
  full usernames. A mismatch denies runtime-object cleanup or managed-object lifecycle writes and wedges the
  corresponding Helm operation.
- **Kueue's own account is the opposite**: upstream derives it from the release name, so the
  allowlist templates it. Kueue writes the `resource-in-use` finalizer on flavors a ClusterQueue
  holds, and a mismatch would deny that under any non-default release name.

The allowlist covers both AKS control-plane identities, `acsService` and `aksService`, the extension
controller and Kueue ServiceAccounts, and the fixed uninstall and WPC-lifecycle hook identities. The
managed-object lifecycle is supported through the AKS Extension RP; direct customer Helm operations
are not supported and may be denied by this policy. Trusted Access is matched on the `aks:trustedaccess:`
prefix instead of a full name: the request arrives impersonated and the impersonator is stripped
before admission sees it.

`matchPolicy: Equivalent` nests under `matchConstraints`. At the spec top level the API server
rejects the whole policy as an unknown field, which a rendered-YAML review does not catch, only a
server-side dry run does.

The policy protects marked objects and reserves generated names before creation. Customers cannot
claim the `aks-` ResourceFlavor namespace, Topology `aks-default`, or the three managed WPC names.
AdmissionCheck and ProvisioningRequestConfig names are not reserved; their future producers must set
the protection marker before those controllers ship.

The binding is `Deny` + `Audit`. `Warn` cannot be set alongside `Deny`, so it is a replacement, not
an addition — and the API server rejects the binding outright if both appear.

⚠️ **Not named `aks-managed-*`.** AKS's own `protect-managed-admissionregistration` policy denies
anyone but AKS creating admissionregistration resources under that prefix, so it would block this
chart's install.

⚠️ **On BYO this is tamper-evidence, not prevention.** A cluster-admin can delete the policy, and
deleting the CRD cascades to its objects without admission running at all.

## Local development

Requires [Helm](https://helm.sh) v3+, the
[helm-unittest plugin](https://github.com/helm-unittest/helm-unittest), `yq`
v4, `jq`, and `patch`.

⚠️ **`scripts/ci/apply-chart-aks-overrides.sh` mutates the target chart in
place.** Run it and `Chart.yaml`, `values.yaml`, `templates/` and `tests/` are
all modified. Work on a copy so generated files cannot end up in a commit.

```bash
# Work on a scratch copy so the tree stays clean
cp -r charts/kueue /tmp/kueue
scripts/ci/apply-chart-aks-overrides.sh /tmp/kueue

helm lint /tmp/kueue --namespace kueue-system
helm unittest /tmp/kueue
helm template test /tmp/kueue --namespace kueue-system
```

Install to a dev cluster:

```bash
helm install kueue /tmp/kueue --namespace kueue-system --create-namespace
helm uninstall kueue --namespace kueue-system
```

## Pipelines

Both pipelines are Azure DevOps, under [`.pipelines/`](../../.pipelines/). They were GitHub Actions before the repository moved to ADO; `.github/workflows/` no longer exists.

### Publish — [`publish-kueue-fork.yml`](../../.pipelines/publish-kueue-fork.yml)

| | |
|---|---|
| **Trigger** | push to `main` touching `charts/kueue/**`, the shared override helper, or the pipeline file |
| **Pool** | `1es-aks-ai-runtime-ado-westus3` |
| **Auth** | service connection `aks ai runtime - prod` |

1. Applies AKS overrides.
2. Reads the composed chart version — **after** step 1, since that is what composes it.
3. Warns if the upstream Kueue image tag is not yet in MCR (a dalec PR may be needed).
4. Lints, runs helm-unittest, validates rendering.
5. Removes `templates-aks/` and `tests-aks/` — the script already copied them into `templates/` and `tests/`, and shipping the originals would duplicate every AKS template in the archive. `.helmignore` is an upstream file that sync overwrites, so removal here is what keeps them out.
6. `helm package`, push to ACR, verify the tag landed.

### Upstream sync — [`sync-kueue-upstream.yml`](../../.pipelines/sync-kueue-upstream.yml)

| | |
|---|---|
| **Trigger** | cron, every other day at 09:00 UTC |
| **Also** | manual run with an optional `upstreamVersion` parameter |

Clones the upstream chart at the resolved tag, overwrites the upstream-owned files, bumps `UPSTREAM_VERSION`, and opens a PR. AKS overrides are **not** applied during sync — the repo always holds raw upstream.

The sync PR is **never auto-merged**. A human reviews the diff and verifies lint, unittest and template before merging. If a patch under `patches/` no longer applies, the script fails loudly and the patch needs rebasing — that is the intended behaviour, since silent divergence from upstream would be worse.

### Publishing manually

```bash
az login && az acr login --name aksmcrimagescommon

cp -r charts/kueue /tmp/kueue
scripts/ci/apply-chart-aks-overrides.sh /tmp/kueue
rm -rf /tmp/kueue/templates-aks /tmp/kueue/tests-aks
helm package /tmp/kueue --destination /tmp/helm-packages
helm push /tmp/helm-packages/kueue-*.tgz \
  oci://aksmcrimagescommon.azurecr.io/public/aks/ai-runtime/helm
```

## Consuming the chart

```bash
az acr login --name aksmcrimagescommon

helm install kueue \
  oci://aksmcrimagescommon.azurecr.io/public/aks/ai-runtime/helm/kueue \
  --version <version> \
  --namespace kueue-system --create-namespace
```

List what is published:

```bash
az acr repository show-tags --name aksmcrimagescommon \
  --repository public/aks/ai-runtime/helm/kueue --output table
```

## Making AKS customizations

### Value overrides (preferred)

Edit [`values-aks-overrides.yaml`](values-aks-overrides.yaml). It is deep-merged onto the upstream `values.yaml` at publish time, so every entry is carried across upstream updates with no manual effort. Add only keys that must differ from upstream.

**Embedded YAML strings**: `managerConfig.controllerManagerConfigYaml` is a YAML string, not a structured object. A plain merge would replace it wholesale, so the script parses it with `from_yaml`, deep-merges, and re-serializes. Adding another embedded-YAML field means adding a similar step.

### Templates and tests

Add the file to `templates-aks/` or `tests-aks/` — never to `templates/` or `tests/` (see the sync warning above).

### Patching an upstream file

For a small change to a file we do not own, add a `.patch` under `patches/`. This keeps a targeted diff instead of a full-file overlay that would silently mask upstream changes. `aks-featuregates.patch` is the one in use today: it routes the MultiKueue feature gate through `aksExtension.enableMultiKueue` by patching upstream's `_helpers.tpl`.

## Customer-facing metrics (Azure Monitor managed Prometheus)

Kueue's controller-manager exposes Prometheus metrics — queue depth, admission latency, quota usage, preemptions. This chart can ship a `ServiceMonitor` that makes a cluster's Azure Monitor managed Prometheus addon scrape them into the customer's own Azure Monitor workspace.

It is **off by default**. Ingestion is billed to the customer, so a scrape job they did not ask for costs them money.

### Enabling it

**Prerequisites** — both are the customer's to provision and pay for:

1. An Azure Monitor workspace.
2. The managed Prometheus addon on the cluster:
   ```bash
   az aks update -n <cluster> -g <rg> --enable-azure-monitor-metrics
   ```
   This installs the `azmonitoring.coreos.com` CRDs and the `ama-metrics` pods.

Then enable the flag:

```bash
helm upgrade kueue <chart> -n kueue-system \
  --set aksExtension.metrics.azureManagedPrometheus.enabled=true
```

⚠️ **Order matters.** The template is guarded by `.Capabilities.APIVersions.Has "azmonitoring.coreos.com/v1"`, which Helm evaluates at render time. Enabling the addon *after* installing the chart renders nothing until the next `helm upgrade`. The guard exists because without it a real `helm install` fails on any cluster lacking the addon with `resource mapping not found for kind "ServiceMonitor" ... ensure CRDs are installed first`. Note `helm template` and `--dry-run` do not fail, since neither reaches the API server.

If you deploy this chart through kustomize's `helmCharts:` rather than Helm directly, list the API version explicitly — kustomize renders without cluster capabilities, so the guard suppresses the object and nothing reports it:

```yaml
helmCharts:
  - name: kueue
    apiVersions:
      - azmonitoring.coreos.com/v1
```

### Verifying

Azure portal → the Azure Monitor workspace → Managed Prometheus → Prometheus explorer, then query:

```promql
kueue_build_info
```

⚠️ **An empty result does not mean a broken scrape.** Prometheus client libraries do not emit a metric until its first observation, so most `kueue_*` series are simply **absent** — not zero — until ClusterQueues, LocalQueues and workloads exist. On an idle cluster only a handful of series exist. Create a queue and submit a Job before concluding anything is wrong.

### Self-hosted Prometheus instead

The managed addon deliberately ignores the OSS `monitoring.coreos.com` CRDs, which is why this chart ships an Azure-flavoured object. If you run your own Prometheus Operator, enable upstream's ServiceMonitor instead:

```bash
helm upgrade kueue <chart> -n kueue-system --set enablePrometheus=true
```

That renders `monitoring.coreos.com/v1`, which the Azure addon will not read. The two are independent; enabling both is valid if you run both collectors.

⚠️ Upstream's object has **no** capability guard, so unlike the Azure one it fails the install outright if the Prometheus Operator CRDs are absent. Install the operator first.

Both paths read `metrics.serviceMonitor.tlsConfig`. Without cert-manager they skip verification for Kueue's default self-signed certificate. With `enableCertManager=true`, the upstream ServiceMonitor verifies the Service DNS name and the CA from `kueue-metrics-server-cert`; the Azure-specific object continues to skip verification unless given an explicit `tlsConfig`.

### What is not covered

- **The extension controller's own metrics** (port 8080). Those are internal signals — a GPU SKU missing from the compiled table is a Microsoft bug, not something a customer can act on — and they are not exposed here. They reach Microsoft-internal monitoring through the `aks-operator` vmagent scrape configuration; see [`controllers/kueue-extension/docs/METRICS.md`](../../controllers/kueue-extension/docs/METRICS.md).
- **Dashboards.** This delivers collection only.
